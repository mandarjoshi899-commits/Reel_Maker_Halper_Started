// Supabase Edge Function: supabase/functions/generate/index.ts
// Set OPENAI_API_KEY as a Supabase Function Secret. Never put it in index.html.
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const apiKey = Deno.env.get("OPENAI_API_KEY");
  if (!apiKey) return Response.json({ error: "AI key is not configured" }, { status: 500 });
  const { topic, category, duration, language, message } = await req.json();
  if (!topic || typeof topic !== "string" || topic.length > 180) {
    return Response.json({ error: "Please provide a short topic." }, { status: 400 });
  }
  const prompt = `Create an original, family-friendly short-form social video plan.
Language: ${language || "Hindi + Hinglish"}
Topic: ${topic}
Category: ${category}
Duration: ${duration}
Extra message: ${message || "Choose a fitting positive message"}
Return ONLY valid JSON with this shape:
{"title":"short title","script":"complete spoken script with hook, story and CTA","scenes":[["Scene 1","0-5 sec","camera/visual direction","dialogue/action"],["Scene 2","...","...","..."]]}
Make 4-6 concise scenes. Do not imitate a living creator. Avoid dangerous stunts, graphic violence, hateful content, or copyrighted song lyrics.`;
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        temperature: 0.8,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: "You create original, safe short-video scripts. Return valid JSON only." },
          { role: "user", content: prompt }
        ]
      })
    });
    if (!response.ok) return Response.json({ error: "AI provider request failed" }, { status: 502 });
    const data = await response.json();
    const result = JSON.parse(data.choices?.[0]?.message?.content || "{}");
    if (!result.title || !result.script || !Array.isArray(result.scenes)) {
      return Response.json({ error: "AI returned an invalid format" }, { status: 502 });
    }
    return Response.json(result);
  } catch (_e) {
    return Response.json({ error: "Could not generate script right now." }, { status: 500 });
  }
});
